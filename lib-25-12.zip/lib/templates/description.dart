import 'package:flutter/material.dart';
import 'package:lista/templates/clip_rect.dart';

class DescriptionPage extends StatelessWidget {
  final String data;
  final String image;
  final String icon;
  final Color color;

  const DescriptionPage({Key key, @required this.data,@required this.image,@required this.icon,@required this.color}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Column(
      children: [
        Container(
          height: size.height * 0.1,
          color: Colors.blueAccent,
          child: Column(
              children: [
                Expanded(child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Image.asset(
                      icon
                  ),
                )),
                Divider(
                  color: Colors.white,
                  thickness: 2,
                )
              ]
          ),
        ),
        Expanded(
          child: Stack(
            children: [
              Align(
                alignment: Alignment.center,
                child: Text(data),
              ),
              ClipPath(
                child: Container(
                  color: color,
                ),
                clipper: CustomRect(),
              )
            ],
          ),
        ),
      ],
    );
  }
}
