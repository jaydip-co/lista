import 'package:flutter/material.dart';
import 'package:lista/templates/description.dart';
import 'package:lista/templates/gamepage.dart';
import 'package:lista/templates/namepage.dart';

class GameTemplate extends StatefulWidget {
  @override
  _GameTemplateState createState() => _GameTemplateState();
}

class _GameTemplateState extends State<GameTemplate> {

  final _controller  = PageController(initialPage: 0);
  int index = 0;

  @override
  void initState() {
    // _controller.addListener(() {
    //   if(_controller.page < index)
    //     _controller.jumpToPage(index);
    // });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return PageView(
      controller: _controller,
      children: [
        NamePage(color: Colors.blue, icon: "asset/image/pig.png",name: 'Name'),
        DescriptionPage(color: Colors.blue,icon: "asset/image/pig.png",data: "blah blah blah .........",),
        GamePage()
      ],
      onPageChanged: (i) {
        index = i;
      },
    );
  }
}
